 #!/bin/bash 

#running script in backend
cd  backend
perl BackEnd.pl
